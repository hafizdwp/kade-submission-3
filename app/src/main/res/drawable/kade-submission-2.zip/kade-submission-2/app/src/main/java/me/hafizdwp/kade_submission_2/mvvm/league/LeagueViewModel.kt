package me.hafizdwp.kade_submission_2.mvvm.league

import android.app.Application
import me.hafizdwp.kade_submission_2.base.BaseViewModel
import me.hafizdwp.kade_submission_2.data.MyRepository

class LeagueViewModel(application: Application,
                      val mRepository: MyRepository) : BaseViewModel(application) {

}

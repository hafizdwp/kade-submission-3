package me.hafizdwp.kade_submission_2.base

/**
 * @author hafizdwp
 * 27/09/2019
 **/
interface BaseProgressListener {
    fun onFailedRetryClick()
}
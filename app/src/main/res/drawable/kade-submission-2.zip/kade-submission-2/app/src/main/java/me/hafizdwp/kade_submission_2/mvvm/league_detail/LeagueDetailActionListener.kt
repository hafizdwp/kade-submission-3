package me.hafizdwp.kade_submission_2.mvvm.league_detail

import me.hafizdwp.kade_submission_2.base.BaseProgressListener
import me.hafizdwp.kade_submission_2.data.source.remote.model.MatchResponse

/**
 * @author hafizdwp
 * 06/11/2019
 **/
interface LeagueDetailActionListener : BaseProgressListener {
    fun onMatchClick(data: MatchResponse)
}
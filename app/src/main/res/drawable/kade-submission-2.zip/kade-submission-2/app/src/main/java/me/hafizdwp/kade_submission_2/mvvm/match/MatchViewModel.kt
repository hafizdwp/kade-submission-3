package me.hafizdwp.kade_submission_2.mvvm.match

import android.app.Application
import me.hafizdwp.kade_submission_2.base.BaseViewModel
import me.hafizdwp.kade_submission_2.data.MyRepository


class MatchViewModel(application: Application,
                     val mRepository: MyRepository) : BaseViewModel(application) {

}

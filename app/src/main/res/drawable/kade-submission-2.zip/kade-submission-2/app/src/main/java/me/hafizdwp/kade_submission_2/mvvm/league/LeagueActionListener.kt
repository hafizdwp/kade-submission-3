package me.hafizdwp.kade_submission_2.mvvm.league

/**
 * @author hafizdwp
 * 30/10/2019
 **/
interface LeagueActionListener {
    fun onLeagueClick(data: LeagueData)
}
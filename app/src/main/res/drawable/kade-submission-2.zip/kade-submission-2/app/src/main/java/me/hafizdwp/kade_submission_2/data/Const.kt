package me.hafizdwp.kade_submission_2.data

/**
 * @author hafizdwp
 * 10/07/19
 **/
object Const {
    const val DATABASE_NAME = "my.db"
}